"""The three observation surfaces: durable, live and execution-coupled."""

from __future__ import annotations

import copy
import threading
import time
from collections.abc import AsyncIterator, Callable, Iterator
from typing import Any, Protocol, runtime_checkable

__all__ = [
    "TraceSink", "TraceRunSink", "Listener", "InMemoryTraceSink",
    "StreamDriver", "AsyncStreamDriver",
]


_TERMINAL_KINDS = frozenset({"run_completed", "run_failed", "run_cancelled"})


def _iterator_is_finished(iterator: Any) -> bool:
    """Whether the underlying generator has actually terminated.

    A driver latches itself closed when its iterator is done, so that a later
    context exit cannot cancel an unrelated run (ADR-008 §1). But not every
    exception out of ``next``/``__anext__`` means "done": a concurrency clash
    raises ``RuntimeError``/``ValueError`` while the generator is very much
    alive, and latching on that abandons a live run with no terminal record.
    A finished generator has released its frame; anything else has not.
    """
    for attribute in ("gi_frame", "ag_frame", "cr_frame"):
        if hasattr(iterator, attribute):
            return getattr(iterator, attribute) is None
    return True  # not a generator: assume the exception ended it


def _iterator_is_running(iterator: Any) -> bool:
    """Whether another caller is inside this generator right now.

    Draining a generator someone else is executing does not cancel it — it
    raises ("generator already executing" / "asynchronous generator is already
    running") and leaves the run with no terminal record, which is strictly
    worse than not draining at all.  The caller already inside will reach the
    terminal; the cancellation is bound either way.

    Both drivers ask the same question here deliberately.  This guard existed on
    the asynchronous side only, and the synchronous side stranded runs for
    exactly as long as the two were written separately.
    """
    for attribute in ("gi_running", "ag_running", "cr_running"):
        if hasattr(iterator, attribute):
            return bool(getattr(iterator, attribute))
    return False


@runtime_checkable
class TraceRunSink(Protocol):
    """One run-scoped durable session receiving ordered record batches.

    ``finish`` is called exactly once, when the runtime will send nothing more.
    Without it a session cannot tell *in flight* from *abandoned forever* — the
    runtime only ever called ``open_run`` then ``write``, so a sink had no
    moment at which it could treat a file as final, and a run torn down before
    its terminal left a partial artifact indistinguishable from a live one
    (ADR-011).

    ``complete`` is the whole signal: True when the session received a terminal
    record and the sequence is a whole trace, False when it did not and the
    persisted account is a prefix. A sink that omits ``finish`` keeps the old
    behaviour and forfeits only that distinction.

    ``finish`` is **deliberately not declared as a member below**. Python has no
    optional protocol member: declaring it would make ``isinstance`` and every
    static checker reject a write-only sink, which is exactly the break ADR-011
    promises not to impose. The runtime therefore duck-types it, the same way it
    already duck-types ``write`` at bind time. The signature a sink must provide
    is::

        def finish(self, *, complete: bool) -> None: ...

    A durable sink should implement it; :class:`InMemoryTraceSink` does, so the
    shipped sink demonstrates the whole shape.
    """

    def write(self, records: tuple[dict[str, Any], ...]) -> None: ...


@runtime_checkable
class TraceSink(Protocol):
    """Factory binding a trace header to one durable run session.

    ``header`` is the document's ``TraceHeader`` — ``{schema_version, run}`` —
    so a sink can write a conforming artifact from what it is handed, without
    importing anything from the writer.
    """

    def open_run(self, header: dict[str, Any]) -> TraceRunSink: ...


@runtime_checkable
class Listener(Protocol):
    """Live read-only surface.

    Record mutation and callback failures are isolated.  Delivery is
    synchronous, so callbacks can delay the runner and code holding the
    Runtime may use its public cancellation surface.
    """

    def on_record(self, record: dict[str, Any]) -> None: ...


class _InMemoryRunSink:
    __slots__ = ("header", "_records", "complete")

    def __init__(self, header: dict[str, Any]) -> None:
        self.header = copy.deepcopy(header)
        self._records: list[dict[str, Any]] = []
        self.complete: bool | None = None

    def write(self, records: tuple[dict[str, Any], ...]) -> None:
        self._records.extend(copy.deepcopy(records))

    def finish(self, *, complete: bool) -> None:
        # `None` until the runtime says otherwise, so "still in flight" and
        # "ended with a prefix" stay distinguishable — which is the whole point
        # of the signal. The shipped sink implements it so that the example
        # people copy is the complete shape.
        self.complete = complete

    @property
    def records(self) -> tuple[dict[str, Any], ...]:
        return tuple(copy.deepcopy(self._records))


class InMemoryTraceSink:
    """Run-partitioned test sink with no crash-persistence promise."""

    __slots__ = ("_runs", "_lock")

    def __init__(self) -> None:
        self._runs: list[_InMemoryRunSink] = []
        self._lock = threading.Lock()

    def open_run(self, header: dict[str, Any]) -> TraceRunSink:
        run = _InMemoryRunSink(header)
        with self._lock:
            self._runs.append(run)
        return run

    @property
    def header(self) -> dict[str, Any] | None:
        with self._lock:
            return copy.deepcopy(self._runs[-1].header) if self._runs else None

    @property
    def records(self) -> tuple[dict[str, Any], ...]:
        with self._lock:
            return self._runs[-1].records if self._runs else ()

    @property
    def runs(self) -> tuple[dict[str, Any], ...]:
        with self._lock:
            runs = tuple(self._runs)
        return tuple(
            {"header": copy.deepcopy(run.header), "records": list(run.records)}
            for run in runs
        )


class _ObservationHub:
    """Runtime-owned delivery coordinator; deliberately not public."""

    __slots__ = (
        "profile", "sink", "listeners", "chunk_records", "flush_interval_ms",
        "_buffer", "_last_flush", "listener_failures", "_lock", "_timer",
        "_async_failure", "_closed", "_run_sink", "_saw_terminal",
    )

    def __init__(
        self,
        *,
        profile: str,
        sink: TraceSink | None,
        listeners: tuple[Listener | Callable[[dict[str, Any]], None], ...],
        chunk_records: int,
        flush_interval_ms: int,
    ) -> None:
        if profile not in ("in-memory", "buffered", "synchronous"):
            raise ValueError(f"unsupported durability profile {profile!r}")
        if profile != "in-memory" and sink is None:
            raise ValueError(f"durability profile {profile!r} requires a TraceSink")
        if isinstance(chunk_records, bool) or not isinstance(chunk_records, int) or chunk_records < 1:
            raise ValueError("chunk_records must be an integer >= 1")
        if isinstance(flush_interval_ms, bool) or not isinstance(flush_interval_ms, int) or flush_interval_ms < 0:
            raise ValueError("flush_interval_ms must be an integer >= 0")
        self.profile = profile
        self.sink = sink
        self.listeners = listeners
        self.chunk_records = chunk_records
        self.flush_interval_ms = flush_interval_ms
        self._buffer: list[dict[str, Any]] = []
        self._last_flush = time.monotonic()
        self.listener_failures = 0
        self._lock = threading.RLock()
        self._timer: threading.Timer | None = None
        self._async_failure: BaseException | None = None
        self._closed = False
        self._run_sink: TraceRunSink | None = None
        self._saw_terminal = False

    @property
    def evidence(self) -> str:
        """Whether this run's durable evidence is whole, and answerable to a caller.

        `_saw_terminal` is the same fact `_signal_finish` hands the sink as
        `complete=`, read from the other side. The session was always told; the
        caller was not, on any terminal but `run_completed` — so a run whose
        evidence had been refused returned a `RunResult` byte-identical to a
        healthy one, and the only party still able to retry, alert or withhold
        the decision was the only party that could not tell (#42).

        `self.sink` is never cleared, unlike `_run_sink`, so the distinction
        between "nothing durable was promised" and "something was promised and
        is missing" survives `close()`. Collapsing those two into one boolean
        would make the in-memory profile report a durability failure it never
        offered — the same class of false statement in the other direction.
        """
        if self.sink is None:
            return "not-required"
        return "persisted" if self._saw_terminal else "incomplete"

    def bind(self, header: dict[str, Any]) -> None:
        """Open the required run-scoped session without losing its failure."""
        if self.sink is None:
            return
        try:
            session = self.sink.open_run(copy.deepcopy(header))
            if not callable(getattr(session, "write", None)):
                raise TypeError("TraceSink.open_run must return a TraceRunSink")
            self._run_sink = session
        except BaseException as exc:
            self._async_failure = exc

    def _cancel_timer_locked(self) -> None:
        timer, self._timer = self._timer, None
        if timer is not None:
            timer.cancel()

    def _schedule_timer_locked(self) -> None:
        if (
            self._timer is not None or self._closed or not self._buffer
            or self.flush_interval_ms <= 0
        ):
            return
        elapsed = (time.monotonic() - self._last_flush) * 1000
        delay = max(0.0, (self.flush_interval_ms - elapsed) / 1000)
        self._timer = threading.Timer(delay, self._timer_flush)
        self._timer.daemon = True
        self._timer.start()

    def _flush_locked(self) -> None:
        if not self._buffer:
            return
        assert self._run_sink is not None
        batch = tuple(copy.deepcopy(self._buffer))
        try:
            self._run_sink.write(batch)
        except BaseException as exc:
            self._async_failure = exc
            raise
        if any(record["kind"] in _TERMINAL_KINDS for record in batch):
            self._saw_terminal = True
        self._buffer.clear()
        self._last_flush = time.monotonic()

    def _timer_flush(self) -> None:
        with self._lock:
            self._timer = None
            if self._closed or self._async_failure is not None:
                return
            try:
                self._flush_locked()
            except BaseException:
                # The runner observes the stored failure at its next
                # persistence boundary; terminal success always forces one.
                return

    def persist(self, record: dict[str, Any], *, force: bool = False) -> None:
        if self._async_failure is not None:
            raise self._async_failure
        if self.profile == "in-memory" and self._run_sink is None:
            return
        assert self._run_sink is not None
        if self.profile in ("in-memory", "synchronous"):
            try:
                self._run_sink.write((copy.deepcopy(record),))
            except BaseException as exc:
                # Latch, exactly as the buffered path already does. A write
                # that raised may still have committed — the canonical lost
                # acknowledgement, which guarantees.md invariant II explicitly
                # contemplates by naming replication. The runtime cannot tell,
                # so it must not write to this session again: a retry that
                # lands beside a record which did commit produces a duplicate
                # `seq` and, on the terminal, one artifact asserting both that
                # the run completed and that it failed. OPEN-08 licenses a
                # truncated prefix; it does not license a corrupted suffix.
                self._async_failure = exc
                raise
            if record["kind"] in _TERMINAL_KINDS:
                self._saw_terminal = True
            return
        with self._lock:
            if self._async_failure is not None:
                raise self._async_failure
            self._buffer.append(copy.deepcopy(record))
            elapsed_ms = (time.monotonic() - self._last_flush) * 1000
            should_flush = force or len(self._buffer) >= self.chunk_records
            if self.flush_interval_ms == 0 or elapsed_ms >= self.flush_interval_ms:
                should_flush = True
            if should_flush:
                self._cancel_timer_locked()
                self._flush_locked()
            else:
                self._schedule_timer_locked()

    def best_effort(self, record: dict[str, Any]) -> None:
        try:
            self.persist(record, force=True)
        except BaseException:
            pass

    def notify(self, record: dict[str, Any]) -> None:
        for listener in self.listeners:
            delivered = copy.deepcopy(record)
            try:
                method = getattr(listener, "on_record", None)
                if method is not None:
                    method(delivered)
                else:
                    listener(delivered)  # type: ignore[misc]
            except BaseException:
                self.listener_failures += 1

    def close(self) -> None:
        """Stop background scheduling, and hand over what is still held.

        Every terminal record force-flushes, so a run that reaches one leaves
        nothing behind. A run that does *not* — a node raising ``BaseException``,
        a cancelled task, an abandoned driver — used to arrive here with its
        buffer full and have it discarded: the trace named 47 records, the sink
        received 0, and the process was alive the whole time.

        The buffered profile's declared loss window (``guarantees.md`` invariant
        II) is about evidence lost *with the process*. ADR-008 §2 is explicit
        that it "does not license silent loss while the process is alive", and
        node-protocol §7.3 requires an interrupted attempt's unclosed
        ``attempt_started`` to be visible evidence rather than an erased gap.

        Best-effort: a sink that refuses here has already failed the run by
        every path that cares, and a failure stored earlier is never retried —
        that would be the retry-after-failure this class deliberately refuses.
        """
        with self._lock:
            self._cancel_timer_locked()
            if self._async_failure is None:
                try:
                    self._flush_locked()
                except BaseException:
                    pass  # _flush_locked has already stored it
            self._closed = True
            session, self._run_sink = self._run_sink, None
        if session is not None:
            self._signal_finish(session)

    def _signal_finish(self, session: TraceRunSink) -> None:
        """Tell the session the runtime will send it nothing more.

        Optional on the sink's side: a session without ``finish`` behaves as it
        always did. Called outside the lock, because it reaches user code that
        may block on a filesystem or a network, and holding `_lock` across that
        stalls anything else touching this hub.

        Best-effort. The run has already reached whatever end it was going to
        reach; raising here would replace that outcome with a bookkeeping
        failure, and `_async_failure` is not set because there is nothing left
        to refuse.
        """
        finish = getattr(session, "finish", None)
        if not callable(finish):
            return
        try:
            finish(complete=self._saw_terminal)
        except BaseException:
            pass


class StreamDriver(Iterator[dict[str, Any]]):
    """Consumer-paced execution surface.

    The runtime cannot advance until the consumer asks for the next record.
    ``close`` is an explicit cooperative cancellation: it drains only the
    cancellation terminal, never the pending node attempt.
    """

    # `__weakref__` is explicit because the runtime attaches a finaliser to a
    # driver: a driver dropped before it was ever advanced must still release
    # the run it claimed, and a slotted class is not weak-referenceable by
    # default.
    __slots__ = (
        "_iterator", "_cancel", "_closed", "_trace_getter", "_evidence_getter",
        "_requested",
        "_close_lock", "__weakref__",
    )

    def __init__(
        self,
        iterator: Iterator[dict[str, Any]],
        cancel: Callable[[str], None],
        trace_getter: Callable[[], Any],
        evidence_getter: Callable[[], str | None] = lambda: "not-required",
    ) -> None:
        self._iterator = iterator
        self._cancel = cancel
        self._closed = False
        self._requested = False
        # Re-entrant: a listener is delivered synchronously from inside the
        # generator this drain advances, so a listener closing its own driver
        # re-enters `close` on the very thread already holding this.
        self._close_lock = threading.RLock()
        self._trace_getter = trace_getter
        self._evidence_getter = evidence_getter

    def __iter__(self) -> "StreamDriver":
        return self

    def __next__(self) -> dict[str, Any]:
        if self._closed:
            raise StopIteration
        try:
            return next(self._iterator)
        except BaseException:
            # Exhaustion and execution failures both finish this driver.  In
            # particular, normal exhaustion must make context-manager exit a
            # no-op rather than queueing cancellation for a later run.  A
            # concurrency clash does NOT finish it — latching there would
            # abandon a live run with no terminal record.
            if _iterator_is_finished(self._iterator):
                self._closed = True
            raise

    @property
    def trace(self) -> Any:
        return self._trace_getter()

    @property
    def evidence(self) -> str:
        """Whether this run's durable evidence is whole — see EvidenceStatus.

        The streaming surfaces are where a caller is most obviously still able
        to act — it is inside the loop — and #42's first fix reached only
        `run()`/`arun()`, so `stream()` consumers kept receiving a run whose
        evidence had been destroyed with nothing to distinguish it from a
        healthy one. An adversarial round found that; the value was already
        computed and sitting one attribute away behind the driver.

        Raises while the run is unfinished, following `RunResult.status`: a run
        that has not reached a terminal has no durability answer, and returning
        the initial `not-required` would be a lie for the whole duration of the
        stream — the shape of defect this attribute exists to end.
        """
        answer = self._evidence_getter()
        if answer is None:
            raise ValueError(
                "this run has not finished: its evidence is undecided until a "
                "terminal record is written. Iterate to exhaustion, or close() "
                "and read it then."
            )
        return answer

    def close(self, reason: str = "stream consumer stopped") -> None:
        if self._closed:
            return
        # Serialised, not merely guarded. Two threads closing one driver is an
        # ordinary supervisor shape, and a bare check-then-act loses twice:
        # both reach `_cancel`, and `Runtime.cancel` is last-writer-wins, so the
        # trace names a request that did not stop the run; and both reach the
        # drain, so the loser's `next()` raises "generator already executing"
        # out of `close`, and therefore out of `__exit__`.
        with self._close_lock:
            if self._closed:
                return
            if not self._requested:
                # The cancellation that actually stopped the run is the first
                # one. A second close (a retry, or __exit__ after an explicit
                # call) must not overwrite the reason the trace attributes it
                # to.
                #
                # The latch is set only once the cancellation has bound.
                # Setting it first burns it on a call that never cancelled — a
                # non-str reason, an interrupt landing between the two
                # statements — and then the retry, or __exit__, skips the
                # cancel and drains instead: `close` would execute every
                # remaining node, performing their external effects, where
                # guarantees.md §6 requires a recorded run_cancelled.
                self._cancel(reason)
                self._requested = True
            if _iterator_is_running(self._iterator):
                # Someone is inside this generator right now — a listener is
                # delivered synchronously from within it, so a listener closing
                # its own driver lands here, re-entering this lock on its own
                # thread. Draining would raise "generator already executing"
                # and orphan the run with no terminal. The cancellation is
                # bound; whoever is inside drives it to run_cancelled and
                # closes this driver on the way out.
                return
            try:
                while True:
                    next(self._iterator)
            except StopIteration:
                pass
            finally:
                self._closed = True

    def __enter__(self) -> "StreamDriver":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if not self._closed:
            self.close("stream context exited")


class AsyncStreamDriver(AsyncIterator[dict[str, Any]]):
    """The asynchronous twin of :class:`StreamDriver`.

    Same contract, same cancellation semantics: the runtime cannot advance
    until the consumer asks for the next record, exhaustion closes the driver
    so a later context exit cannot cancel an unrelated run (ADR-008 §1), and
    ``aclose`` on a live run drains only the cancellation terminal.
    """

    __slots__ = (
        "_iterator", "_cancel", "_closed", "_trace_getter", "_evidence_getter",
        "_requested",
        "__weakref__",
    )

    def __init__(
        self,
        iterator: AsyncIterator[dict[str, Any]],
        cancel: Callable[[str], None],
        trace_getter: Callable[[], Any],
        evidence_getter: Callable[[], str | None] = lambda: "not-required",
    ) -> None:
        self._iterator = iterator
        self._cancel = cancel
        self._closed = False
        self._requested = False
        self._trace_getter = trace_getter
        self._evidence_getter = evidence_getter

    def __aiter__(self) -> "AsyncStreamDriver":
        return self

    async def __anext__(self) -> dict[str, Any]:
        if self._closed:
            raise StopAsyncIteration
        try:
            return await self._iterator.__anext__()
        except BaseException:
            # Exhaustion and execution failures both finish this driver, so
            # context exit afterwards is a no-op rather than a cancellation
            # queued against a later run.  "asynchronous generator is already
            # running" is neither: the generator is alive and another task is
            # inside it, so latching there would strand that run for good.
            if _iterator_is_finished(self._iterator):
                self._closed = True
            raise

    @property
    def trace(self) -> Any:
        return self._trace_getter()

    @property
    def evidence(self) -> str:
        """Whether this run's durable evidence is whole — see EvidenceStatus.

        The streaming surfaces are where a caller is most obviously still able
        to act — it is inside the loop — and #42's first fix reached only
        `run()`/`arun()`, so `stream()` consumers kept receiving a run whose
        evidence had been destroyed with nothing to distinguish it from a
        healthy one. An adversarial round found that; the value was already
        computed and sitting one attribute away behind the driver.

        Raises while the run is unfinished, following `RunResult.status`: a run
        that has not reached a terminal has no durability answer, and returning
        the initial `not-required` would be a lie for the whole duration of the
        stream — the shape of defect this attribute exists to end.
        """
        answer = self._evidence_getter()
        if answer is None:
            raise ValueError(
                "this run has not finished: its evidence is undecided until a "
                "terminal record is written. Iterate to exhaustion, or close() "
                "and read it then."
            )
        return answer

    async def aclose(self, reason: str = "stream consumer stopped") -> None:
        if self._closed:
            return
        if not self._requested:
            # The cancellation that actually stopped the run is the first one.
            # A second aclose (a retry, or __aexit__ after an explicit call)
            # must not overwrite the reason the trace will attribute it to.
            # Latched only once it has bound — see StreamDriver.close.
            self._cancel(reason)
            self._requested = True
        if _iterator_is_running(self._iterator):
            # A consumer is inside __anext__ right now — the graceful-shutdown
            # shape, where a supervisor closes a driver another task is
            # reading. Draining here would raise "asynchronous generator is
            # already running" and orphan the run with no terminal. The
            # cancellation is bound; the consumer drives it to run_cancelled
            # and closes this driver on the way out.
            return
        try:
            while True:
                await self._iterator.__anext__()
        except StopAsyncIteration:
            pass
        finally:
            self._closed = True

    async def __aenter__(self) -> "AsyncStreamDriver":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        if not self._closed:
            await self.aclose("stream context exited")
